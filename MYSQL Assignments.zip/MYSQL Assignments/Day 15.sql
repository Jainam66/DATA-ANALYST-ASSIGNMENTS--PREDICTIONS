
####------------------- Day 15 ---------------------#### 


#Create the table Emp_BIT. Add below fields in it.
#Create before insert trigger to make sure any new value of Working_hours, if it is negative, then it should be inserted as positive.
use Assignments;
truncate emp_bit;
Create Table Emp_BIT (
Name Varchar(20) not Null,
Occupation Varchar (20) not null,
Working_date date,
Working_Hours Time);
INSERT INTO Emp_BIT VALUES
('Robin', 'Scientist', '2020-10-04', 12),  
('Warner', 'Engineer', '2020-10-04', 10),  
('Peter', 'Actor', '2020-10-04', 13),  
('Marco', 'Doctor', '2020-10-04', 14),  
('Brayden', 'Teacher', '2020-10-04', 12),  
('Antonio', 'Business', '2020-10-04', -11);  

DELIMITER //

CREATE TRIGGER emp_bit_BEFORE_INSERT
BEFORE INSERT ON emp_bit
FOR EACH ROW
BEGIN
    IF NEW.Working_hours < 0 THEN
        SET NEW.Working_hours = -NEW.Working_hours;
    END IF;
END//

DELIMITER ;
select * from Emp_BIT;