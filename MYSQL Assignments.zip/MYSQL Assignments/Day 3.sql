####------------------- Day 3 ---------------------#### 

### Show customer number, customer name, state and credit limit from customers table for below conditions. Sort the results by highest to lowest values of creditLimit.
##State should not contain null values
##credit limit should be between 50000 and 100000
 Use classicmodels;
 select * from customers;
SELECT customerNumber, CustomerName, State, CreditLimit
FROM Customers
WHERE State IS NOT NULL
  AND CreditLimit BETWEEN 50000 AND 100000
ORDER BY CreditLimit DESC;
