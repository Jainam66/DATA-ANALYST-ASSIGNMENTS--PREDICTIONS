
####------------------- Day 12 ---------------------####    


##1)	Calculate year wise, month name wise count of orders and year over year (YoY) percentage change. Format the YoY values in no decimals and show in % sign.
##Table: Orders

select * from orders;

WITH MonthlyOrderCounts AS (
    SELECT
        YEAR(orderdate) AS Year,
        MONTH(orderdate) AS OrderMonth,
        MONTHNAME(orderdate) AS Month,
        COUNT(ordernumber) AS OrderCount
    FROM
        Orders
    GROUP BY
        Year, OrderMonth, Month
),
YoYPercentageChange AS (
    SELECT
        a.Year,
        a.OrderMonth,
        a.Month,
        a.OrderCount AS CurrentYearCount,
        COALESCE(b.OrderCount, 0) AS PreviousYearCount,
        CASE
            WHEN b.OrderCount > 0 THEN ((a.OrderCount - b.OrderCount) / b.OrderCount) * 100
            ELSE 100 -- Handle division by zero for the first year
        END AS YoYPercentageChange
    FROM
        MonthlyOrderCounts a
    LEFT JOIN
        MonthlyOrderCounts b ON a.OrderMonth = b.OrderMonth AND a.Year = b.Year + 1
)
SELECT
    Year,
    Month,
    SUM(CurrentYearCount) AS TotalOrder,
    CONCAT(FORMAT(YoYPercentageChange, 0), '%') AS YoYPercentageChangeFormatted
FROM
    YoYPercentageChange
GROUP BY
    Year, Month, YoYPercentageChange
ORDER BY
    Year, MONTH(Month);

##2) 2)	Create the table emp_udf with below fields.   ●	Emp_ID    ●	Name  ●	DOB   Add the data as shown in below query.
drop table  if exists emp_udf;
CREATE TABLE emp_udf (
    Emp_ID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    DOB DATE NOT NULL
);

INSERT INTO Emp_UDF(Name, DOB)
VALUES ("Piyush", "1990-03-30"), ("Aman", "1992-08-15"), ("Meena", "1998-07-28"), ("Ketan", "2000-11-21"), ("Sanjay", "1995-05-21");

##creating the user define function
-- Create calculate_age function
DELIMITER //
CREATE FUNCTION calculate_age(dob DATE)
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE years INT;
    DECLARE months INT;
    DECLARE age VARCHAR(50);

    SET years = TIMESTAMPDIFF(YEAR, dob, CURDATE());
    SET months = TIMESTAMPDIFF(MONTH, dob, CURDATE()) % 12;

    SET age = CONCAT(years, ' years ', months, ' months');

    RETURN age;
END //
DELIMITER ;
#result
SELECT EMP_ID,Name,DOB, calculate_age(DOB) AS Age FROM emp_udf;