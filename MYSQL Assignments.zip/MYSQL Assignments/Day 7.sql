
####------------------- Day 7 ---------------------#### 


##	Show employee number, Sales Person (combination of first and last names of employees), unique customers for each employee number and sort the data by highest to lowest unique customers.
##Tables: Employees, Customers

show tables;
show databases;
USE classicmodels;

select * from employees;
select * from customers;
SELECT 
    E.employeenumber,
    CONCAT(E.firstname, ' ', E.lastname) AS Sales_Person,
    COUNT(DISTINCT C.customerNumber) AS Unique_Customers
FROM Employees E
left JOIN Customers C ON E.employeenumber = C.salesRepEmployeenumber
GROUP BY E.employeenumber, Sales_Person
ORDER BY Unique_Customers DESC;


 ##2)	Show total quantities, total quantities in stock, left over quantities for each product and each customer. Sort the data by customer number.

##Tables: Customers, Orders, Orderdetails, Products
select * from customers;
select * from orders;
select * from orderdetails;
select * from products;

select 
C.customernumber,
C.customername,
P.productcode,
P.productname,
sum(OA.quantityordered) as Torder,
 P.quantityInStock as Qinstock,
(P.quantityinstock - sum(OA.quantityordered)) as Leftover
 from customers C
 join orders O on C.customerNumber= O.Customernumber
 join orderdetails OA on O.ordernumber=OA.ordernumber
 join products P on OA.productcode = P.productCode
group by C.customerNumber, P.productCode 
  order by C.customerNumber;

##3)	Create below tables and fields. (You can add the data as per your wish)

##●	Laptop: (Laptop_Name)
##●	Colours: (Colour_Name)
##Perform cross join between the two tables and find number of rows.
create table laptop(
laptopname varchar(20));
create table colours(
colourname varchar(20));

insert into laptop values ("Dell"),("HP");
insert into colours values ("white"),("silver"),("Black");

SELECT L.laptopname, C.colourname
FROM laptop L
CROSS JOIN colours C;

##4)	Create table project with below fields.
##●	EmployeeID ●	FullName ●	Gender ●	ManagerID  Add below data into it.
##Find out the names of employees and their related managers	.
drop table project;
use classicmodels;
create table project(
EmployeeID int,
FullName varchar(50),
Gender varchar(10),
managerID int);
INSERT INTO Project VALUES(1, 'Pranaya', 'Male', 3);
INSERT INTO Project VALUES(2, 'Priyanka', 'Female', 1);
INSERT INTO Project VALUES(3, 'Preety', 'Female', NULL);
INSERT INTO Project VALUES(4, 'Anurag', 'Male', 1);
INSERT INTO Project VALUES(5, 'Sambit', 'Male', 1);
INSERT INTO Project VALUES(6, 'Rajesh', 'Male', 3);
INSERT INTO Project VALUES(7, 'Hina', 'Female', 3);

select * from project;
 
select M.fullname as managername,
MM.fullname as employeename
from project as M
inner join project as MM
on M.employeeID = MM.managerID
order by MM.managerID;