
####------------------- Day 4 ---------------------#### 


use classicmodels;

   ##1)	Show the orderNumber, status and comments from orders table for shipped status only. If some comments are having null values then show them as “-“.
select * from orders;
select orderNumber,status, ifnull(comments, '-') as comments
from orders 
where status="shipped";
 
 ##2)	Select employee number, first name, job title and job title abbreviation from employees table based on following conditions If job title is one among the below conditions, then job title abbreviation column should show below forms.
/*	President then “P”*/
/*	Sales Manager / Sale Manager then “SM”*/
/*	Sales Rep then “SR”*/
/*	Containing VP word then “VP”*/
select * from employees;
select distinct jobtitle from employees; 
select employeeNumber,firstName,jobTitle,
case
when jobTitle ="president" then "P"
when jobTitle like "VP%" then "VP"
when jobTitle like "%sales manager%" then "SM"
when jobTitle like "%sale manager%" then "SM"
when jobtitle="sales Rep" then "SR"
else jobtitle
end as job_title_abbrivation
from employees;