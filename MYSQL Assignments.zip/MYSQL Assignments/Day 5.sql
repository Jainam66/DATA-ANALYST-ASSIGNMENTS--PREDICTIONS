####------------------- DAY 5 ---------------------#### 

##1)	For every year, find the minimum amount value from payments table.
use classicmodels;
select * from payments;
select year(paymentdate) as paymentyear,min(amount) as Min_AMOUNT 
from payments 
group by paymentyear 
order by paymentyear;

##2)	For every year and every quarter, find the unique customers and total orders from orders table. Make sure to show the quarter as Q1,Q2 etc.
use classicmodels;
select * from orders;
select 
 date_format(orderdate,"%Y") as year,                    
 concat("Q",quarter(orderdate)) as quarter,
 count(distinct customernumber) as unique_Customers,
 count(*) as totalorders
from orders 
 group by year,quarter
 order by year,quarter;

##3)Show the formatted amount in thousands unit (e.g. 500K, 465K etc.) for every month (e.g. Jan, Feb etc.) with filter on total amount as 500000 to 1000000. Sort the output by total amount in descending mode. [ Refer. Payments Table]

SELECT
  DATE_FORMAT(paymentdate, "%b") AS month,
  CONCAT(FORMAT(SUM(amount) / 1000, 0), 'K') AS formatted_amount
FROM
  Payments
GROUP BY
  month
HAVING
  SUM(amount) BETWEEN 500000 AND 1000000
ORDER BY
  SUM(amount) DESC;



#As Result There is NO any Amount Data present is Present Between 500k and 100k data as for cross check...
Select * from Payments where amount between 500000 and 1000000;  
select * from payments where amount >100000;
# all values are greater than 100k...

