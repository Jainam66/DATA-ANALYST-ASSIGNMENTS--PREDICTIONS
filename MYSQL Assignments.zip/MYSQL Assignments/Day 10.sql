####------------------- Day 10 ---------------------#### 
#Create the view products status. Show year wise total products sold. Also find the percentage of total value for each year. The output should look as shown in below figure.
drop view products_status;

create or replace view  product_status as 
SELECT
  YEAR(o.orderdate) AS year,
  sum(od.quantityOrdered) as sum,
CONCAT(COUNT(*), ' (', (COUNT(*) * 100.0 / (SELECT count(*) FROM orderdetails)), '%)') AS value
FROM orders o 
JOIN orderdetails od ON o.ordernumber = od.ordernumber
GROUP BY YEAR(o.orderdate)
ORDER BY sum DESC;



SELECT year, value
FROM products_status;


use classicmodels;
show tables from classicmodels;
select * from orderdetails;
select * from orders;