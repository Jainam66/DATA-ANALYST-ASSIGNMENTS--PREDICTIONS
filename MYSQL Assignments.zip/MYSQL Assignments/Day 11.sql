
####------------------- Day 11 ---------------------#### 
#1)	Create a stored procedure GetCustomerLevel which takes input as customer number and gives the output as either Platinum, Gold or Silver as per below criteria.
##Table: Customers
##	Platinum: creditLimit > 100000
#	Gold: creditLimit is between 25000 to 100000
#	Silver: creditLimit < 25000
use classicmodels;
SELECT * FROM customers;

DELIMITER //
CREATE PROCEDURE Assignment11_1  (IN A_customerNumber INT)
BEGIN
    DECLARE B_creditLimit DECIMAL(10, 2);

    SELECT creditLimit INTO B_creditLimit
    FROM Customers
    WHERE customerNumber = A_customerNumber;
    IF B_creditLimit > 100000 THEN
        SELECT 'Platinum' AS CustomerLevel;
    ELSEIF B_creditLimit BETWEEN 25000 AND 100000 THEN
        SELECT 'Gold' AS CustomerLevel;
    ELSE
        SELECT 'Silver' AS CustomerLevel;
    END IF;
END

//DELIMITER ;

##2)	Create a stored procedure Get_country_payments which takes in year and country as inputs and gives year wise, country wise total amount as an output. Format the total amount to nearest thousand unit (K)
#Tables: Customers, Payments
use classicmodels;
Select * from Customers;
Select * from Payments;

DELIMITER //
CREATE PROCEDURE Assignment11_2 (IN p_year INT, IN p_country VARCHAR(50))
BEGIN
    SELECT 
        YEAR(paymentDate) AS PaymentYear,
        country AS Country,
        CONCAT(FORMAT(SUM(amount) / 1000, 0), 'K') AS TotalAmountInK
    FROM
        Payments
    INNER JOIN Customers ON Payments.customerNumber = Customers.customerNumber
    WHERE
        YEAR(paymentDate) = p_year AND Customers.country = p_country
    GROUP BY
        PaymentYear, Country;
END //
DELIMITER ;
