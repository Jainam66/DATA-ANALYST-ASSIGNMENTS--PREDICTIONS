
####------------------- Day 8 ---------------------#### 

##1)Create table facility. Add the below fields into it.●	Facility_ID ●	Name ●	State ●	Country
##i) Alter the table by adding the primary key and auto increment to Facility_ID column.
##ii) Add a new column city after name with data type as varchar which should not accept any null values.

Create Table Facility(
Facility_ID int primary key auto_increment,
Name Varchar(20),
State Varchar(20),
Country Varchar(20));

desc facility;
alter table Facility add column city Varchar(20) not null After Name;
select * from Facility;