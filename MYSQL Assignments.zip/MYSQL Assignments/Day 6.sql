
####------------------- Day 6 ---------------------#### 

##1)	Create a journey table with following fields and constraints.
##	Bus_ID (No null values)
##	Bus_Name (No null values)
##	Source_Station (No null values)
##	Destination (No null values)
##	Email (must not contain any duplicates)
drop table journey;
create table journey(
Bus_ID int(50) not null,
Bus_Name varchar(50) not null,
Source_Station varchar(50) not null,
destination varchar(50) not null,
Email varchar(50) primary key);
desc journey;
select * from journey;
insert into journey
values(01,"shivshai","Pune","Kolhapur","jainamjain@gmail.com"),
(02,"PMPL","Pune","Jalgaon","janj@gmail.com"),
(03,"Khuraana","amalner","jalgaon","jas@gmail.com"),
(04,"kai","sangli","satara","modi@gmail.com");

##2)	Create vendor table with following fields and constraints.

##	Vendor_ID (Should not contain any duplicates and should not be null)
##	Name (No null values)
##	Email (must not contain any duplicates)
##	Country (If no data is available then it should be shown as “N/A”)

create table Vendor(
Vendor_ID int not null,
Name varchar(50) not null,
Email char(100) not null unique,
country varchar(50) default "NA", 
primary key(Vendor_ID));
select * from vendor;
Desc vendor;

##3)	Create movies table with following fields and constraints.

##	Movie_ID (Should not contain any duplicates and should not be null)
##	Name (No null values)
##	Release_Year (If no data is available then it should be shown as “-”)
##	Cast (No null values)
##	Gender (Either Male/Female)
##	No_of_shows (Must be a positive number)
drop table movie;
Create table Movie(
Movie_ID int primary key,
Name varchar(50) not null,
Release_Year char(50) default "-",
Cast varchar(50) not null,
Gender char(1) check(gender in ("M","F")),
NO_OF_Shows int check (NO_OF_Shows>=1)
);
desc movie;
select * from movie;
insert into movie(movie_id,name,cast,gender,no_of_shows) value (01,"KGF3","ram mauli","M",01);


##4)	Create the following tables. Use auto increment wherever applicable
##a. Product
##✔	product_id - primary key
##✔	product_name - cannot be null and only unique values are allowed
##✔	description
##✔	supplier_id - foreign key of supplier table
##b. Suppliers
##✔	supplier_id - primary key
##✔	supplier_name
##✔	location
##c. Stock
##✔	id - primary key
##✔	product_id - foreign key of product table
##✔	balance_stock

create table supplier(
supplier_id int primary key auto_increment,
supplier_name varchar(200) not null,
location varchar(200)not null);

create table product(
product_id int primary key auto_increment,
product_name varchar(200) not null unique,
description varchar(2000),
supplier_id int not null,
foreign key (supplier_id) 
references supplier(supplier_id)
);

create table stock(
id int auto_increment primary key,
product_id int not null,
balance_stock varchar(200) not null,
foreign key (product_id)references product (product_id));

desc supplier;
select * from supplier;
desc product;
select * from product;
desc stock;
select * from stock;