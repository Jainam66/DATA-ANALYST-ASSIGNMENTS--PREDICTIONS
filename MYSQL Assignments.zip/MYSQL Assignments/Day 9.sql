####------------------- Day 9 ---------------------#### 

##Create table university with below fields. ●	ID ● Name. Add the below data into it as it is.Remove the spaces from everywhere and update the column like Pune University etc.

truncate table university;

Create Table University (
ID int,
Name varchar(50)
);
select * from university; 
INSERT INTO University
VALUES (1, "       Pune          University     "), 
               (2, "  Mumbai          University     "),
              (3, "     Delhi   University     "),
              (4, "Madras University"),
              (5, "Nagpur University");
UPDATE university
SET name = TRIM(BOTH '  ' FROM REPLACE(name, '   ', ' '));

