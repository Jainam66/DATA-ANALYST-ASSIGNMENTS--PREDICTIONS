
####------------------- Day 14 ---------------------####

#Create the table Emp_EH. Below are its fields.   ●	EmpID (Primary Key)   ●	EmpName   ●	EmailAddress
#Create a procedure to accept the values for the columns in Emp_EH. Handle the error using exception handling concept. Show the message as “Error occurred” in case of anything wrong.

drop table if exists Emp_eh;
CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(255),
    EmailAddress VARCHAR(255)
);
select * from Emp_EH;      

create table Emp_error(
empID int,
empname varchar(255),
message varchar(255),
tot datetime);
select * from Emp_error;

CREATE TABLE Emp_EH (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(255),
    EmailAddress VARCHAR(255)
);

## Here we have created the two Types of error using exception handling  1) In this the the error will store in the different table. 
																	
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `Continue_Error Handling_1062`(EmpID int , EmPName varchar(250), EmailAddress varchar (250))
BEGIN
declare continue Handler for 1062
begin 
insert into Emp_error (empID,empname ,message ,tot) values ( EmpID, EmpName,"Froud Detection",now());
end;
insert into Emp_EH values (EmpID,EMPName,EmailAddress);
END //
DELIMITER ;

#    2)In this the error will message will be display on front as the error message. (Extra)

DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertEmpEH`(
    IN p_EmpID INT,
    IN p_EmpName VARCHAR(255),
    IN p_EmailAddress VARCHAR(255)
)
BEGIN
    DECLARE error_occurred BOOLEAN DEFAULT FALSE;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        SET error_occurred := TRUE;
    END;

    START TRANSACTION;

    INSERT INTO Emp_EH (EmpID, EmpName, EmailAddress)
    VALUES (p_EmpID, p_EmpName, p_EmailAddress);
    
    IF error_occurred THEN
        insert into Emp_error (empID,empname ,message ,tot) values ( EmpID, EmpName,"Froud Detection",now());

        ROLLBACK;
        SELECT 'Error occurred. Entry logged in ErrorEntries table.' AS Message;
    ELSE
        COMMIT;
        SELECT 'Record inserted successfully' AS Message;
    END IF;
END
// 
DELIMITER ;